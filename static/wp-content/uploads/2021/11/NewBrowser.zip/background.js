var i = 0;
var url = 'https://www.paypal.me/typicalness';
var donate = false;
var web = new Array("webview1", "webview2", "webview3", "webview4", "webview5");
var home = 'http://www.google.com';
//chrome.storage.sync.get('home', function(b){
//	if(b > 3){
//		chrome.storage.sync.get('home',function(u){
//			var home = u;
//		}
//		)
//	}
//	else{
//		var home = 'http://www.google.com';
//	}
//})
function createWindow(param) {
	chrome.app.window
			.create(
					'window.html',
					{
						id : web[i]
					},
					function(appwindow) {

						appwindow.contentWindow.onload = function() {
							var userText = "";
							// declares userText
							window.MutationObserver = window.MutationObserver
									|| window.WebKitMutationObserver
									|| window.MozMutationObserver;
							var target = appwindow.contentWindow.document
									.getElementById('browser'), observer = new MutationObserver(
									function(mutation) {
										appwindow.contentWindow.document
												.getElementById('webBar').value = appwindow.contentWindow.document
												.getElementById('browser')
												.getAttribute("src");
									}), config = {
								attributes : true
							};
							observer.observe(target, config);
							appwindow.contentWindow.document
									.getElementById('backButton').onclick = function() {
								appwindow.contentWindow.document
										.getElementById('browser').back();
							}
							appwindow.contentWindow.document
									.getElementById('forwardButton').onclick = function() {
								appwindow.contentWindow.document
										.getElementById('browser').forward();
							}
							appwindow.contentWindow.document
									.getElementById('newWindow').onclick = function() {
								i += 1;
								donate = false;
								createWindow({
									'launch' : 'empty'
								});

							}
							appwindow.contentWindow.document
									.getElementById('donate').onclick = function() {
								createWindow({
									'launch' : 'empty'
								});
								donate = true;
								i += 1;
							}
							if (donate) {
								appwindow.contentWindow.document
										.getElementById('browser')
										.setAttribute('src', url);
							}
							if (!donate) {
								appwindow.contentWindow.document
										.getElementById('browser')
										.setAttribute('src', home);
							}

							appwindow.contentWindow.document
									.getElementById('setHome').onkeypress = function(
									d) {
								d = d || window.event;
								if (d.keyCode == 13) {
									text = appwindow.contentWindow.document
											.getElementById('setHome').value;
									home = text;
									home = home.replace("https://", "");
									home = home.replace("http://", "");
									home = home.replace("www.", "");
									home = "https://www." + home;
									appwindow.contentWindow.document
											.getElementById('browser')
											.setAttribute("src", home);
									return false;
								}
								chrome.storage.sync.set({
									'home' : home
								});
							}
							appwindow.contentWindow.document.getElementById('homeButton').onclick=function(){
								appwindow.contentWindow.document
								.getElementById('browser')
								.setAttribute("src", home);
							}

							appwindow.contentWindow.document
									.getElementById('webBar').onkeypress = function(
									e) {
								e = e || window.event;
								if (e.keyCode == 13) {
									userText = appwindow.contentWindow.document
											.getElementById('webBar').value;
									var fullURL = userText;
									fullURL = fullURL.replace("https://", "");
									fullURL = fullURL.replace("http://", "");
									fullURL = fullURL.replace("www.", "");
									fullURL = "https://www." + fullURL;
									appwindow.contentWindow.document
											.getElementById('browser')
											.setAttribute("src", fullURL);
									return false;
								}
							}
							appwindow.contentWindow.document
									.getElementById('webBar').onfocus = function() {
								if (appwindow.contentWindow.document
										.getElementById('webBar').value == appwindow.contentWindow.document
										.getElementById('browser')
										.getAttribute("src"))
									// checks to see if text in omnibox is the
									// same as the src from the browser
									appwindow.contentWindow.document
											.getElementById('webBar').select();
								// selects the webBar
							}
							appwindow.contentWindow.document
									.getElementById('refreshButton').onclick = function() {
								appwindow.contentWindow.document
										.getElementById('browser').reload();
							}// allows refreshing
							appwindow.contentWindow.document
									.getElementById('browser')
									.addEventListener(
											'loadabort',
											function(e) { // loadabort event
												// fires when a page
												// failed to load,
												// will redirect to
												// google search
												// query
												// allows webBar to be an
												// omnibox that defaults to
												// google
												// maybe change to duckduckgo?
												if (e.reason == "ERR_NAME_NOT_RESOLVED"
														|| e.reason == "ERR_INVALID_URL") {
													var googleURL = "https://www.google.com/#q=";
													var inputData = userText;
													inputData = inputData
															.split(" ");
													for (var i = 0; i < inputData.length; i++) {
														googleURL += inputData[i];
														googleURL += "+"
													}
													googleURL = googleURL
															.slice(
																	0,
																	googleURL.length - 1);
													appwindow.contentWindow.document
															.getElementById(
																	'browser')
															.setAttribute(
																	"src",
																	googleURL);
												}
											});
							toggleFullscreen = function() {
								if (appwindow.isFullscreen())
									appwindow.restore();
								else
									appwindow.fullscreen();
							};
						};
					});
}

chrome.runtime.onMessageExternal.addListener(function(request, sender) {
	if (typeof request.launch === 'undefined')
		return;

	if (sender.id === extId || sender.id === devId) {
		chrome.storage.local.set({
			'extension' : true
		});
		hasExt = true;
	}

	if (0 === chrome.app.window.getAll().length) {
		createWindow(request);
		createWindow(request);
	}

	else {
		var appwindow = chrome.app.window.getAll()[0];
		appwindow.close();
		setTimeout(function() {
			createWindow(request);
		}, 1000);

	}
});

chrome.app.runtime.onLaunched.addListener(function() {
	createWindow({
		'launch' : 'empty'
	});
	i += 1;
});

var minimized = false;